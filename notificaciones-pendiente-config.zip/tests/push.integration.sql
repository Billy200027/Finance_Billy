-- All fixtures and notifications are rolled back; never dispatch test data.
begin;
do $$
declare a uuid; u uuid:=gen_random_uuid(); v uuid:=gen_random_uuid(); sa uuid:=gen_random_uuid(); su uuid:=gen_random_uuid(); sv uuid:=gen_random_uuid();
 da uuid:=gen_random_uuid(); du uuid:=gen_random_uuid(); dv uuid:=gen_random_uuid(); ba uuid:=gen_random_uuid(); bu uuid:=gen_random_uuid(); bv uuid:=gen_random_uuid();
 n uuid; r uuid; rec uuid; batch jsonb; before_n int; count_n int;
begin
 select id into a from finance_billy.members where role='ADMIN';
 if a is null then raise exception 'Missing administrator'; end if;
 insert into auth.users(id) values(u),(v);
 insert into auth.sessions(id,user_id) values(sa,a),(su,u),(sv,v);
 insert into finance_billy.members(id,cedula,name,status) values(u,'999991000001','Push Fixture A','APROBADA'),(v,'999991000002','Push Fixture B','APROBADA');
 perform public.finance_push_device(a,sa,da,ba,repeat('A',50),true);
 perform public.finance_push_device(u,su,du,bu,repeat('B',50),true);
 perform public.finance_push_device(v,sv,dv,bv,repeat('C',50),true);
 insert into finance_billy.news(title,body) values('Push fixture','Test only') returning id into n;
 select count(*) into count_n from finance_billy.push_deliveries where device_id in(da,du,dv) and page='Noticias';
 if count_n<>3 then raise exception 'News routing failed: %',count_n; end if;
 update finance_billy.news set body='Edited' where id=n;
 if (select count(*) from finance_billy.push_deliveries where device_id in(da,du,dv) and page='Noticias')<>3 then raise exception 'Edit duplicated news'; end if;
 insert into finance_billy.requests(user_id,amount,weeks,rate,snapshot_points,bank_snapshot) values(u,4000,5,0.01,100,'{}') returning id into r;
 if (select count(*) from finance_billy.push_deliveries where device_id in(da,du,dv) and page='Solicitudes')<>1 or not exists(select 1 from finance_billy.push_deliveries where device_id=da and page='Solicitudes') then raise exception 'Request routing leaked'; end if;
 update finance_billy.requests set status='APROBADA_PENDIENTE_DESEMBOLSO' where id=r;
 if not exists(select 1 from finance_billy.push_deliveries where device_id=du and page='Préstamos') or exists(select 1 from finance_billy.push_deliveries where device_id in(da,dv) and page='Préstamos') then raise exception 'Approval routing leaked'; end if;
 update finance_billy.requests set reason='No duplicate' where id=r;
 if (select count(*) from finance_billy.push_deliveries where device_id=du and page='Préstamos')<>1 then raise exception 'Duplicate approval'; end if;
 insert into finance_billy.receipts(user_id,kind,declared,path,key) values(u,'ACTIVACION',100,u||'/test.png',gen_random_uuid()) returning id into rec;
 if (select count(*) from finance_billy.push_deliveries where device_id in(da,du,dv) and page='Comprobantes')<>1 or not exists(select 1 from finance_billy.push_deliveries where device_id=da and page='Comprobantes') then raise exception 'Receipt routing leaked'; end if;
 -- Same phone switches account. Its old deliveries cannot be claimed.
 perform public.finance_push_device(v,sv,du,gen_random_uuid(),repeat('B',50),true);
 delete from auth.sessions where id=sv;
 batch:=public.finance_push_claim();
 if exists(select 1 from jsonb_array_elements(batch) x where (x->>'device_id')::uuid in(du,dv)) then raise exception 'Session/account switch leak'; end if;
 if exists(select 1 from finance_billy.push_deliveries where device_id in(du,dv) and status<>'SKIPPED') then raise exception 'Invalid recipient not skipped'; end if;
 if jsonb_array_length(public.finance_push_claim())<>0 then raise exception 'Lease allowed duplicate claims'; end if;
 perform public.finance_push_device(a,sa,da,null,null,false);
 if exists(select 1 from finance_billy.push_devices where id=da) or exists(select 1 from finance_billy.push_deliveries where device_id=da) then raise exception 'Unsubscribe failed'; end if;
 if has_function_privilege('anon','public.finance_push_device(uuid,uuid,uuid,uuid,text,boolean)','execute') or has_function_privilege('authenticated','public.finance_push_claim()','execute') then raise exception 'Public RPC exposed'; end if;
end $$;
select 'PASS: news, edits, admin-only receipts/requests, private approvals, switch, revocation, leases, unsubscribe, grants' as result;
rollback;
