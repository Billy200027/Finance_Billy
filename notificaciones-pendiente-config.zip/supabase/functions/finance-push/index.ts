// FCM credential remains exclusively in Supabase secrets.
const base=Deno.env.get('SUPABASE_URL')!,key=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const secret=Deno.env.get('FINANCE_PUSH_WORKER_KEY')||'';
const enc=new TextEncoder();
const b64=(v:Uint8Array)=>btoa(String.fromCharCode(...v)).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
async function rpc(name:string,data:unknown={}){
 const r=await fetch(base+'/rest/v1/rpc/'+name,{method:'POST',headers:{apikey:key,Authorization:'Bearer '+key,'Content-Type':'application/json'},body:JSON.stringify(data)});
 if(!r.ok)throw Error('DATABASE'); return r.json();
}
let cached:{value:string,until:number}|undefined;
async function accessToken(){
 if(cached&&cached.until>Date.now())return cached.value;
 const account=JSON.parse(Deno.env.get('FCM_SERVICE_ACCOUNT_JSON')||'{}');
 if(account.project_id!=='finance-billy-notificaciones'||account.type!=='service_account')throw Error('CONFIG');
 const now=Math.floor(Date.now()/1000);
 const payload=b64(enc.encode(JSON.stringify({alg:'RS256',typ:'JWT'})))+'.'+b64(enc.encode(JSON.stringify({iss:account.client_email,scope:'https://www.googleapis.com/auth/firebase.messaging',aud:'https://oauth2.googleapis.com/token',iat:now,exp:now+3600})));
 const pem=account.private_key.replace(/-----[^-]+-----/g,'').replace(/\s/g,'');
 const pk=await crypto.subtle.importKey('pkcs8',Uint8Array.from(atob(pem),c=>c.charCodeAt(0)),{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['sign']);
 const signed=payload+'.'+b64(new Uint8Array(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',pk,enc.encode(payload))));
 const r=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'urn:ietf:params:oauth:grant-type:jwt-bearer',assertion:signed})});
 const j=await r.json();if(!r.ok||!j.access_token)throw Error('GOOGLE_AUTH');
 cached={value:j.access_token,until:Date.now()+Math.max(60,Number(j.expires_in)-120)*1000};return cached.value;
}
async function send(message:unknown,validate=false){
 const r=await fetch('https://fcm.googleapis.com/v1/projects/finance-billy-notificaciones/messages:send',{method:'POST',headers:{Authorization:'Bearer '+await accessToken(),'Content-Type':'application/json'},body:JSON.stringify({message,...(validate?{validate_only:true}:{})})});
 const j=await r.json(); const code=j.error?.details?.find((d:any)=>d.errorCode)?.errorCode||j.error?.status||String(r.status);
 return {ok:r.ok,status:r.status,code};
}
Deno.serve(async(req:Request)=>{
 const reply=(data:unknown,status=200)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
 if(req.method!=='POST')return reply({error:'METHOD'},405);
 const supplied=req.headers.get('x-finance-worker')||'';
 // Constant-time compare of digest avoids revealing secret prefixes.
 const a=new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode(supplied))),b=new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode(secret)));
 let diff=0;for(let i=0;i<a.length;i++)diff|=a[i]^b[i];if(!secret||diff)return reply({error:'UNAUTHORIZED'},401);
 try{
  const body=await req.json().catch(()=>({}));
  if(body.check===true){const result=await send({topic:'finance-billy-auth-check',data:{check:'true'}},true);return reply({configured:true,googleAuthorized:result.ok,code:result.code},result.ok?200:502);}
  const batch=await rpc('finance_push_claim');let sent=0,failed=0;
  for(const q of batch){
   try{
    const result=await send({token:q.token,data:{binding:q.binding,event_id:q.event_id,title:q.title,body:q.body,page:q.page},android:{priority:'HIGH',ttl:'86400s',restricted_package_name:'com.billy.finance'}});
    const invalid=result.code==='UNREGISTERED';
    const permanent=invalid||result.status===400;
    await rpc('finance_push_finish',{p_id:q.id,p_lease:q.lease,p_status:result.ok?'SENT':permanent?'FAILED':'PENDING',p_code:result.ok?null:result.code,p_invalid:invalid});
    if(result.ok)sent++;else failed++;
   }catch{await rpc('finance_push_finish',{p_id:q.id,p_lease:q.lease,p_status:'PENDING',p_code:'RETRY'});failed++;}
  }
  return reply({processed:batch.length,sent,failed});
 }catch{return reply({error:'PUSH_UNAVAILABLE'},503);}
});
